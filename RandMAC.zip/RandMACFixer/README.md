# RandMAC Fixer

RandMAC Fixer is a Windows Wi-Fi MAC randomization repair and switching tool.

It is designed for cases where normal MAC spoofing tools fail, especially when Windows says MAC randomization is disabled, blocked, or inconsistent even though the Wi-Fi driver claims randomization support.

## What it does

RandMAC Fixer uses the Windows WLAN randomization system instead of risky driver patching:

1. Detects the currently active Wi-Fi interface.
2. Reads the live WLAN interface GUID.
3. Enables WLAN randomization for that exact GUID.
4. Sets the current Wi-Fi profile to daily MAC randomization.
5. Reconnects Wi-Fi.
6. Verifies whether the router-facing MAC changed.

## What it does not do

- Does not install unsigned drivers.
- Does not patch driver INF files.
- Does not delete drivers.
- Does not use kernel drivers.
- Does not exploit Wi-Fi adapters.
- Does not bypass networks you do not own or administer.

This is a privacy, repair, diagnostics, and testing tool for your own PC and networks you are authorized to use.

## Why it exists

Some adapters expose MAC randomization in Device Manager, but Windows may still keep randomization disabled for the active WLAN interface. In the original test case, normal MAC spoofing tools failed, but targeting the current live WLAN interface GUID and reapplying Windows profile randomization successfully changed the active MAC address.

## Features

- Scan current Wi-Fi status.
- Show active WLAN GUID, profile, state, and MAC.
- Backup WLAN and network-related registry keys.
- Backup Wi-Fi profiles without passwords by default.
- Optional Wi-Fi password backup if explicitly enabled.
- Enable/fix MAC randomization.
- Switch to a new randomized MAC.
- Disable randomization and return to the adapter's normal MAC.
- Save redacted diagnostic reports.
- Relaunch as Administrator.

## Requirements

- Windows 10 or Windows 11
- Administrator privileges
- Python 3.10+ if running from source
- A Wi-Fi adapter/driver that supports Windows MAC randomization

## Run from source

Open PowerShell as Administrator in the project folder:

```powershell
py -3 main.py
```

Or double-click:

```text
run_dev.bat
```

## Build the EXE

Double-click:

```text
build.bat
```

The built executable will be created here:

```text
dist\RandMACFixer.exe
```

The build script uses PyInstaller with `--uac-admin`, so the app requests administrator permission when launched.

## Privacy warning

Backups and reports may include adapter names, WLAN GUIDs, SSID/profile names, and MAC addresses.

By default:

- Wi-Fi passwords are not exported during backup.
- Saved reports redact MAC addresses and Wi-Fi passwords.

Only enable password backup if you need full restore data and you will keep the backup folder private.

## Safety warning

Changing MAC randomization can temporarily disconnect Wi-Fi. Save work before switching MACs.

Use only on devices and networks you own or are authorized to administer.

## Credits

Created by Chase Flood with troubleshooting and development assistance from ChatGPT/OpenAI.
