@echo off
setlocal
cd /d "%~dp0"

echo === RandMAC Fixer Build ===
echo Installing build requirement...
py -3 -m pip install -r requirements.txt
if errorlevel 1 goto :err

echo Building EXE with admin prompt...
py -3 -m PyInstaller --onefile --windowed --uac-admin --name RandMACFixer main.py
if errorlevel 1 goto :err

echo.
echo Build complete.
echo EXE location: %CD%\dist\RandMACFixer.exe
echo.
pause
exit /b 0

:err
echo.
echo Build failed. Make sure Python is installed and py launcher works.
pause
exit /b 1
