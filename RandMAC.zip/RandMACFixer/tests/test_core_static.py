"""Small no-dependency checks for parser/redaction logic."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import randmac_core as core  # noqa: E402

SAMPLE_INTERFACES = """
There is 1 interface on the system:

    Name                   : Wi-Fi
    Description            : Realtek 8852BE-VT Wireless LAN WiFi 6 PCI-E NIC
    GUID                   : a9f68a98-a552-49c4-a7c1-f757351e94a8
    Physical address       : f6:0d:13:2d:14:9f
    Interface type         : Primary
    State                  : connected
    SSID                   : JacobandBenextender
    Profile                : JacobandBenextender
"""


def test_parse_wlan_interfaces():
    info = core.parse_wlan_interfaces(SAMPLE_INTERFACES)
    assert info.name == "Wi-Fi"
    assert info.guid == "a9f68a98-a552-49c4-a7c1-f757351e94a8"
    assert info.mac == "f6:0d:13:2d:14:9f"
    assert info.profile == "JacobandBenextender"


def test_normalize_guid():
    assert core.normalize_guid("a9f68a98-a552-49c4-a7c1-f757351e94a8") == "{A9F68A98-A552-49C4-A7C1-F757351E94A8}"


def test_redaction():
    text = "MAC f6:0d:13:2d:14:9f\n<keyMaterial>secret123</keyMaterial>\nSSID 1 : MyWifi"
    redacted = core.redact_sensitive(text, redact_macs=True, redact_ssids=True)
    assert "f6:0d:13:2d:14:9f" not in redacted
    assert "secret123" not in redacted
    assert "MyWifi" not in redacted
    assert "[REDACTED-MAC]" in redacted
    assert "[REDACTED-WIFI-PASSWORD]" in redacted


def test_xml_randomization_block():
    xml = "<WLANProfile><name>x</name></WLANProfile>"
    out = core.ensure_mac_randomization_block(xml, 12345, enable=True)
    assert "<enableRandomization>true</enableRandomization>" in out
    assert "<randomizeEveryday>true</randomizeEveryday>" in out
    assert "<randomizationSeed>12345</randomizationSeed>" in out


if __name__ == "__main__":
    test_parse_wlan_interfaces()
    test_normalize_guid()
    test_redaction()
    test_xml_randomization_block()
    print("All static tests passed.")
