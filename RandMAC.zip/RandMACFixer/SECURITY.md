# Security Policy

RandMAC Fixer is intended for local privacy, diagnostics, and repair on your own Windows PC.

Please do not request or submit features intended to bypass network rules, evade bans, defeat anti-cheat, hide malicious activity, or attack systems.

Reports and backups can contain device identifiers such as SSIDs, WLAN GUIDs, and MAC addresses. Review files before sharing them publicly.
