"""
RandMAC Fixer core engine.

Windows-only. Repairs/switches Windows Wi-Fi MAC randomization by targeting
WLAN AutoConfig state for the current live Wi-Fi interface GUID.

This module intentionally avoids driver deletion, unsigned INF installs,
kernel drivers, stealth behavior, or exploit-style behavior.
"""
from __future__ import annotations

import ctypes
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

if os.name == "nt":
    import winreg  # type: ignore
else:
    winreg = None  # type: ignore

LogFn = Callable[[str], None]


@dataclass
class WifiInfo:
    name: str = ""
    description: str = ""
    guid: str = ""
    mac: str = ""
    state: str = ""
    ssid: str = ""
    profile: str = ""
    raw: str = ""


@dataclass
class CommandResult:
    command: str
    returncode: int
    output: str


def default_log(message: str) -> None:
    print(message)


def is_windows() -> bool:
    return os.name == "nt"


def is_admin() -> bool:
    if not is_windows():
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin() -> None:
    if not is_windows():
        raise RuntimeError("Admin relaunch only works on Windows.")
    params = " ".join([f'"{arg}"' for arg in sys.argv])
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)


def run(command: str, timeout: int = 120) -> CommandResult:
    completed = subprocess.run(
        command,
        shell=True,
        capture_output=True,
        text=True,
        errors="replace",
        timeout=timeout,
    )
    output = (completed.stdout or "") + (completed.stderr or "")
    return CommandResult(command=command, returncode=completed.returncode, output=output)


def run_log(command: str, log: LogFn = default_log, timeout: int = 120) -> CommandResult:
    log(f"> {command}")
    try:
        result = run(command, timeout=timeout)
    except subprocess.TimeoutExpired:
        msg = f"Command timed out after {timeout}s: {command}"
        log(msg)
        return CommandResult(command, 999, msg)
    if result.output.strip():
        log(result.output.rstrip())
    return result


def require_windows_admin() -> None:
    if not is_windows():
        raise RuntimeError("RandMAC Fixer only works on Windows.")
    if not is_admin():
        raise PermissionError("Run as Administrator.")


def parse_wlan_interfaces(raw: str) -> WifiInfo:
    info = WifiInfo(raw=raw)
    patterns = {
        "name": r"^\s*Name\s*:\s*(.+)$",
        "description": r"^\s*Description\s*:\s*(.+)$",
        "guid": r"^\s*GUID\s*:\s*(.+)$",
        "mac": r"^\s*Physical address\s*:\s*(.+)$",
        "state": r"^\s*State\s*:\s*(.+)$",
        "ssid": r"^\s*SSID\s*:\s*(.+)$",
        "profile": r"^\s*Profile\s*:\s*(.+)$",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, raw, flags=re.MULTILINE | re.IGNORECASE)
        if match:
            setattr(info, key, match.group(1).strip())
    return info


def get_active_wifi_info() -> WifiInfo:
    result = run("netsh wlan show interfaces")
    return parse_wlan_interfaces(result.output)


def get_wlan_settings() -> str:
    return run("netsh wlan show settings").output


def randomization_enabled_in_settings(settings: Optional[str] = None) -> bool:
    settings = settings if settings is not None else get_wlan_settings()
    return "MAC randomization enabled" in settings


def get_getmac() -> str:
    return run("getmac /v").output


def get_ipconfig_all() -> str:
    return run("ipconfig /all").output


def normalize_mac(mac: str) -> str:
    return mac.strip().replace("-", ":").lower()


def normalize_guid(guid: str) -> str:
    guid = guid.strip().strip("{}")
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", guid):
        raise ValueError(f"Invalid GUID: {guid!r}")
    return "{" + guid.upper() + "}"


def get_saved_profiles() -> list[str]:
    output = run("netsh wlan show profiles").output
    profiles: list[str] = []
    for line in output.splitlines():
        if "All User Profile" in line and ":" in line:
            profiles.append(line.split(":", 1)[1].strip())
    return profiles


def desktop_path() -> Path:
    return Path.home() / "Desktop"


def write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", errors="replace")


def create_backup(log: LogFn = default_log, include_wifi_passwords: bool = False, include_driver_details: bool = False) -> Path:
    require_windows_admin()
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    backup = desktop_path() / f"RandMACFixer_Backup_{stamp}"
    (backup / "Registry").mkdir(parents=True, exist_ok=True)
    (backup / "WiFiProfiles").mkdir(parents=True, exist_ok=True)
    (backup / "Logs").mkdir(parents=True, exist_ok=True)

    log(f"Backup folder: {backup}")

    registry_exports = {
        "WlanSvc.reg": r"HKLM\SOFTWARE\Microsoft\WlanSvc",
        "WcmSvc.reg": r"HKLM\SOFTWARE\Microsoft\WcmSvc",
        "Network-Class.reg": r"HKLM\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}",
        "HKLM-Policies.reg": r"HKLM\SOFTWARE\Policies",
        "HKCU-Policies.reg": r"HKCU\SOFTWARE\Policies",
    }
    for filename, key in registry_exports.items():
        run_log(f'reg export "{key}" "{backup / "Registry" / filename}" /y', log)

    key_mode = "clear" if include_wifi_passwords else "not exported"
    export_cmd = f'netsh wlan export profile folder="{backup / "WiFiProfiles"}"'
    if include_wifi_passwords:
        export_cmd += " key=clear"
    run_log(export_cmd, log)

    logs = {
        "netsh-wlan-settings.txt": "netsh wlan show settings",
        "netsh-wlan-interfaces.txt": "netsh wlan show interfaces",
        "netsh-wlan-profiles.txt": "netsh wlan show profiles",
        "netsh-wlan-drivers.txt": "netsh wlan show drivers",
        "getmac.txt": "getmac /v",
        "ipconfig-all.txt": "ipconfig /all",
        "adapter-advanced.txt": 'powershell -NoProfile -Command "Get-NetAdapterAdvancedProperty -Name Wi-Fi | Format-List *"',
    }
    if include_driver_details:
        logs.update({
            "pnp-net-devices.txt": 'powershell -NoProfile -Command "Get-PnpDevice -Class Net | Format-List *"',
            "signed-wifi-drivers.txt": 'powershell -NoProfile -Command "Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceName -like \'*Wireless*\' -or $_.DeviceName -like \'*WiFi*\' -or $_.DeviceName -like \'*Realtek*8852*\' } | Format-List *"',
        })

    for filename, command in logs.items():
        result = run(command, timeout=180)
        write_text(backup / "Logs" / filename, result.output)

    restore_notes = f"""RandMAC Fixer restore notes

Backup created: {backup}

Registry backups are in the Registry folder. To restore one manually:
  reg import "path\\to\\file.reg"

Wi-Fi profiles are in the WiFiProfiles folder.
Password export mode: {key_mode}

Restart after restoring registry keys.
"""
    write_text(backup / "RESTORE_NOTES.txt", restore_notes)

    if include_wifi_passwords:
        log("Backup complete. WARNING: Wi-Fi profiles may contain saved Wi-Fi passwords.")
    else:
        log("Backup complete. Wi-Fi passwords were NOT exported.")
    return backup


def set_wlansvc_randomization_for_guid(guid: str, log: LogFn = default_log) -> None:
    require_windows_admin()
    if winreg is None:
        raise RuntimeError("winreg unavailable")

    guid_braced = normalize_guid(guid)
    root_key_path = r"SOFTWARE\Microsoft\WlanSvc\Interfaces"
    iface_key_path = root_key_path + "\\" + guid_braced

    log(f"Target WLAN interface GUID: {guid_braced}")

    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, root_key_path, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, "AllowRandomization", 0, winreg.REG_DWORD, 1)

    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, iface_key_path, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, "RandomMacState", 0, winreg.REG_BINARY, bytes([1, 0, 0, 0]))

    log("WlanSvc registry randomization state set to ON.")


def set_wlansvc_randomization_off_for_guid(guid: str, log: LogFn = default_log) -> None:
    require_windows_admin()
    if winreg is None:
        raise RuntimeError("winreg unavailable")
    guid_braced = normalize_guid(guid)
    iface_key_path = r"SOFTWARE\Microsoft\WlanSvc\Interfaces" + "\\" + guid_braced
    log(f"Target WLAN interface GUID: {guid_braced}")
    with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, iface_key_path, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, "RandomMacState", 0, winreg.REG_BINARY, bytes([0, 0, 0, 0]))
    log("WlanSvc registry randomization state set to OFF for this GUID.")


def set_profile_randomization(profile: str, interface: str, mode: str = "daily", log: LogFn = default_log) -> None:
    require_windows_admin()
    if mode not in {"daily", "yes", "no"}:
        raise ValueError("mode must be daily, yes, or no")
    result = run_log(
        f'netsh wlan set profileparameter name="{profile}" interface="{interface}" Randomization={mode}',
        log,
    )
    if result.returncode != 0:
        raise RuntimeError("Failed to set profile randomization. " + result.output)


def ensure_mac_randomization_block(xml_text: str, seed: int, enable: bool = True) -> str:
    enabled = "true" if enable else "false"
    block = (
        '<MacRandomization xmlns="http://www.microsoft.com/networking/WLAN/profile/v3">\n'
        f'\t<enableRandomization>{enabled}</enableRandomization>\n'
        f'\t<randomizeEveryday>{enabled}</randomizeEveryday>\n'
        f'\t<randomizationSeed>{seed}</randomizationSeed>\n'
        '</MacRandomization>'
    )
    if re.search(r'<MacRandomization\b[\s\S]*?</MacRandomization>', xml_text, re.IGNORECASE):
        return re.sub(r'<MacRandomization\b[\s\S]*?</MacRandomization>', block, xml_text, flags=re.IGNORECASE)
    return re.sub(r'</WLANProfile>\s*$', block + '\n</WLANProfile>\n', xml_text, flags=re.IGNORECASE)


def export_profile_to_temp(profile: str, temp_dir: Path, log: LogFn, key_clear: bool = True) -> Path:
    key = "clear" if key_clear else "absent"
    result = run_log(f'netsh wlan export profile name="{profile}" folder="{temp_dir}" key={key}', log)
    if result.returncode != 0:
        raise RuntimeError("Failed to export Wi-Fi profile. " + result.output)
    matches = list(temp_dir.glob("*.xml"))
    if not matches:
        raise FileNotFoundError("Exported profile XML not found.")
    return matches[0]


def reimport_profile_xml(xml_path: Path, profile: str, interface: str, log: LogFn) -> None:
    run_log(f'netsh wlan disconnect interface="{interface}"', log)
    time.sleep(3)
    run_log(f'netsh wlan delete profile name="{profile}" interface="{interface}"', log)
    result = run_log(f'netsh wlan add profile filename="{xml_path}" interface="{interface}" user=all', log)
    if result.returncode != 0:
        raise RuntimeError("Failed to reimport Wi-Fi profile. " + result.output)
    run_log(f'netsh wlan connect name="{profile}" interface="{interface}"', log)
    time.sleep(10)


def restart_wlan(log: LogFn = default_log) -> None:
    result = run_log('powershell -NoProfile -Command "Restart-Service WlanSvc -Force"', log, timeout=60)
    if result.returncode != 0:
        log("Restart-Service returned non-zero. Trying net stop/start...")
        run_log("net stop WlanSvc", log, timeout=60)
        run_log("net start WlanSvc", log, timeout=60)


def reconnect_current(profile: str, interface: str, log: LogFn = default_log) -> None:
    run_log(f'netsh wlan disconnect interface="{interface}"', log)
    time.sleep(5)
    result = run_log(f'netsh wlan connect name="{profile}" interface="{interface}"', log)
    if result.returncode != 0:
        raise RuntimeError("Failed to reconnect Wi-Fi. " + result.output)
    time.sleep(10)


def force_randomization(log: LogFn = default_log, backup_first: bool = True, include_passwords_in_backup: bool = False) -> dict[str, str]:
    require_windows_admin()
    info = get_active_wifi_info()
    if not info.guid or not info.name:
        raise RuntimeError("Could not detect active Wi-Fi interface. Connect to Wi-Fi first.")
    profile = info.profile or info.ssid
    if not profile:
        raise RuntimeError("Could not detect active Wi-Fi profile/SSID.")

    old_mac = info.mac
    log(f"Current MAC: {old_mac}")

    if backup_first:
        create_backup(log, include_wifi_passwords=include_passwords_in_backup)

    set_wlansvc_randomization_for_guid(info.guid, log)
    set_profile_randomization(profile, info.name, "daily", log)
    restart_wlan(log)
    reconnect_current(profile, info.name, log)

    new_info = get_active_wifi_info()
    new_mac = new_info.mac
    changed = normalize_mac(old_mac) != normalize_mac(new_mac) if old_mac and new_mac else False
    log(f"Old MAC: {old_mac}")
    log(f"New MAC: {new_mac}")
    log("SUCCESS: MAC changed." if changed else "MAC did not change yet.")
    return {
        "interface": info.name,
        "profile": profile,
        "guid": info.guid,
        "old_mac": old_mac,
        "new_mac": new_mac,
        "changed": str(changed),
    }


def switch_mac_now(log: LogFn = default_log) -> dict[str, str]:
    require_windows_admin()
    info = get_active_wifi_info()
    if not info.guid or not info.name:
        raise RuntimeError("Could not detect active Wi-Fi interface. Connect to Wi-Fi first.")
    profile = info.profile or info.ssid
    if not profile:
        raise RuntimeError("Could not detect active Wi-Fi profile/SSID.")

    old_mac = info.mac
    seed = random.randint(1, 2_147_483_647)
    log(f"Current MAC: {old_mac}")
    log(f"New randomization seed: {seed}")

    set_wlansvc_randomization_for_guid(info.guid, log)
    set_profile_randomization(profile, info.name, "daily", log)

    temp_root = Path(tempfile.mkdtemp(prefix="RandMACFixer_"))
    try:
        xml = export_profile_to_temp(profile, temp_root, log, key_clear=True)
        text = xml.read_text(encoding="utf-8", errors="replace")
        text = ensure_mac_randomization_block(text, seed, enable=True)
        xml.write_text(text, encoding="utf-8", errors="replace")
        reimport_profile_xml(xml, profile, info.name, log)
    finally:
        try:
            shutil.rmtree(temp_root, ignore_errors=True)
            log(f"Temporary profile folder deleted: {temp_root}")
        except Exception as exc:
            log(f"Could not delete temp folder {temp_root}: {exc}")

    new_info = get_active_wifi_info()
    new_mac = new_info.mac
    changed = normalize_mac(old_mac) != normalize_mac(new_mac) if old_mac and new_mac else False
    log(f"Old MAC: {old_mac}")
    log(f"New MAC: {new_mac}")
    log("SUCCESS: MAC changed." if changed else "MAC did not change.")
    return {
        "interface": info.name,
        "profile": profile,
        "guid": info.guid,
        "old_mac": old_mac,
        "new_mac": new_mac,
        "seed": str(seed),
        "changed": str(changed),
    }


def disable_randomization(log: LogFn = default_log) -> dict[str, str]:
    require_windows_admin()
    info = get_active_wifi_info()
    if not info.guid or not info.name:
        raise RuntimeError("Could not detect active Wi-Fi interface. Connect to Wi-Fi first.")
    profile = info.profile or info.ssid
    if not profile:
        raise RuntimeError("Could not detect active Wi-Fi profile/SSID.")

    old_mac = info.mac
    set_wlansvc_randomization_off_for_guid(info.guid, log)
    set_profile_randomization(profile, info.name, "no", log)
    restart_wlan(log)
    reconnect_current(profile, info.name, log)
    new_info = get_active_wifi_info()
    new_mac = new_info.mac
    log(f"Old MAC: {old_mac}")
    log(f"New MAC: {new_mac}")
    return {
        "interface": info.name,
        "profile": profile,
        "guid": info.guid,
        "old_mac": old_mac,
        "new_mac": new_mac,
    }


def redact_sensitive(text: str, redact_macs: bool = True, redact_ssids: bool = False) -> str:
    text = re.sub(r"(<keyMaterial>)(.*?)(</keyMaterial>)", r"\1[REDACTED-WIFI-PASSWORD]\3", text, flags=re.IGNORECASE | re.DOTALL)
    text = re.sub(r"(DHCPv6 Client DUID\s*\.\s*\.\s*\.\s*\.\s*:\s*).+", r"\1[REDACTED-DUID]", text, flags=re.IGNORECASE)
    if redact_macs:
        text = re.sub(r"\b([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b", "[REDACTED-MAC]", text)
    if redact_ssids:
        text = re.sub(r"(SSID\s*\d*\s*:\s*).+", r"\1[REDACTED-SSID]", text)
        text = re.sub(r"(Profile\s*:\s*).+", r"\1[REDACTED-PROFILE]", text)
    return text


def create_report(log_text: str, redact: bool = True, redact_ssids: bool = False) -> Path:
    stamp = time.strftime("%Y-%m-%d_%H-%M-%S")
    path = desktop_path() / f"RandMACFixer_Report_{stamp}.txt"
    header = "RandMAC Fixer Report\nGenerated: " + time.strftime("%Y-%m-%d %H:%M:%S") + "\n\n"
    body = redact_sensitive(log_text, redact_macs=redact, redact_ssids=redact_ssids) if redact else log_text
    write_text(path, header + body)
    return path
