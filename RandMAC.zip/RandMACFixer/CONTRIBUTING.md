# Contributing

Thanks for helping improve RandMAC Fixer.

Please keep contributions focused on legitimate privacy, diagnostics, and repair use cases.

Do not submit code for bypassing network restrictions, evading bans, defeating anti-cheat, or hiding malicious activity.

Before submitting changes:

1. Run `self_check.bat` on Windows.
2. Do not commit local backup folders, Wi-Fi profile XMLs, registry exports, or reports.
3. Redact MAC addresses, SSIDs, and passwords from screenshots/logs.
