---
name: Bug report
about: Report a problem with RandMAC Fixer
title: "[Bug] "
labels: bug
assignees: ''
---

## What happened?

## Windows version

## Wi-Fi adapter model

## What button/action failed?

## Did the app run as Administrator?

## Logs / report
Please attach a redacted report from the app. Review it before sharing publicly.
