---
name: Feature request
about: Suggest an improvement for RandMAC Fixer
title: "[Feature] "
labels: enhancement
assignees: ''
---

## Feature idea

## Why would this help?

## Any safety/privacy concerns?
