from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext

import randmac_core as core

APP_TITLE = "RandMAC Fixer"


class RandMACFixerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("980x680")
        self.minsize(900, 560)

        self.log_queue: queue.Queue[str] = queue.Queue()
        self.worker: threading.Thread | None = None

        self.include_passwords = tk.BooleanVar(value=False)
        self.include_driver_details = tk.BooleanVar(value=False)
        self.redact_report = tk.BooleanVar(value=True)
        self.redact_ssids = tk.BooleanVar(value=False)

        self._build_ui()
        self.after(100, self._drain_log_queue)

        if not core.is_windows():
            self.log("This app only works on Windows.")
        elif not core.is_admin():
            self.log("Not running as Administrator. Click 'Relaunch as Admin'.")
        else:
            self.log("Running as Administrator. Ready.")
            self.scan()

    def _build_ui(self):
        top = tk.Frame(self, padx=10, pady=8)
        top.pack(fill=tk.X)

        title = tk.Label(top, text=APP_TITLE, font=("Segoe UI", 18, "bold"))
        title.pack(side=tk.LEFT)

        subtitle = tk.Label(top, text="Windows Wi-Fi GUID randomization repair + switcher", font=("Segoe UI", 10))
        subtitle.pack(side=tk.LEFT, padx=12)

        body = tk.Frame(self, padx=10, pady=4)
        body.pack(fill=tk.BOTH, expand=True)

        left = tk.Frame(body, width=390)
        left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left.pack_propagate(False)

        status_frame = tk.LabelFrame(left, text="Current Wi-Fi", padx=8, pady=8)
        status_frame.pack(fill=tk.X, pady=(0, 10))

        self.status_vars = {
            "Interface": tk.StringVar(value="—"),
            "SSID/Profile": tk.StringVar(value="—"),
            "GUID": tk.StringVar(value="—"),
            "MAC": tk.StringVar(value="—"),
            "State": tk.StringVar(value="—"),
            "Randomization": tk.StringVar(value="—"),
        }

        for row, (label, var) in enumerate(self.status_vars.items()):
            tk.Label(status_frame, text=label + ":", anchor="w", width=14).grid(row=row, column=0, sticky="w")
            tk.Label(status_frame, textvariable=var, anchor="w", wraplength=250, justify="left").grid(row=row, column=1, sticky="w")

        buttons = tk.LabelFrame(left, text="Actions", padx=8, pady=8)
        buttons.pack(fill=tk.X)

        self._add_button(buttons, "Scan", self.scan)
        self._add_button(buttons, "Backup", self.backup)
        self._add_button(buttons, "Enable / Fix Randomization", self.fix_randomization)
        self._add_button(buttons, "Switch MAC Now", self.switch_mac)
        self._add_button(buttons, "Disable Randomization / Restore Real MAC", self.disable_randomization)
        self._add_button(buttons, "Verify", self.verify)
        self._add_button(buttons, "Save Report", self.save_report)
        self._add_button(buttons, "Relaunch as Admin", self.relaunch_admin)

        options = tk.LabelFrame(left, text="Options", padx=8, pady=8)
        options.pack(fill=tk.X, pady=10)
        tk.Checkbutton(options, text="Backup saved Wi-Fi passwords (not recommended)", variable=self.include_passwords, anchor="w", justify="left").pack(fill=tk.X)
        tk.Checkbutton(options, text="Include advanced driver details in backup", variable=self.include_driver_details, anchor="w", justify="left").pack(fill=tk.X)
        tk.Checkbutton(options, text="Redact MACs/passwords in saved reports", variable=self.redact_report, anchor="w", justify="left").pack(fill=tk.X)
        tk.Checkbutton(options, text="Also redact SSID/profile names in reports", variable=self.redact_ssids, anchor="w", justify="left").pack(fill=tk.X)

        warning = tk.Message(
            left,
            width=360,
            text=(
                "This app uses Windows WLAN randomization only. It does not install modified drivers, "
                "delete drivers, bypass networks, or exploit adapters. Use only on your own PC. "
                "Temp clear-profile exports used for switching are deleted automatically."
            ),
            font=("Segoe UI", 9),
        )
        warning.pack(fill=tk.X, pady=5)

        right = tk.Frame(body)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.log_box = scrolledtext.ScrolledText(right, wrap=tk.WORD, font=("Consolas", 10))
        self.log_box.pack(fill=tk.BOTH, expand=True)

        bottom = tk.Frame(self, padx=10, pady=6)
        bottom.pack(fill=tk.X)
        self.footer = tk.StringVar(value="Ready")
        tk.Label(bottom, textvariable=self.footer, anchor="w").pack(side=tk.LEFT)

    def _add_button(self, parent, text, command):
        btn = tk.Button(parent, text=text, command=command, width=38, pady=5)
        btn.pack(fill=tk.X, pady=3)

    def log(self, message: str):
        self.log_box.insert(tk.END, message + "\n")
        self.log_box.see(tk.END)
        self.footer.set(message[:150])

    def thread_log(self, message: str):
        self.log_queue.put(message)

    def _drain_log_queue(self):
        while True:
            try:
                msg = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self.log(msg)
        self.after(100, self._drain_log_queue)

    def run_worker(self, name: str, target):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo(APP_TITLE, "A task is already running.")
            return

        def wrapped():
            try:
                self.thread_log(f"\n=== {name} ===")
                target()
            except Exception as exc:
                self.thread_log(f"ERROR: {exc}")
            finally:
                self.thread_log(f"=== {name} finished ===\n")

        self.worker = threading.Thread(target=wrapped, daemon=True)
        self.worker.start()

    def update_status(self):
        info = core.get_active_wifi_info()
        settings = core.get_wlan_settings()
        self.status_vars["Interface"].set(info.name or "—")
        self.status_vars["SSID/Profile"].set(info.profile or info.ssid or "—")
        self.status_vars["GUID"].set(info.guid or "—")
        self.status_vars["MAC"].set(info.mac or "—")
        self.status_vars["State"].set(info.state or "—")
        self.status_vars["Randomization"].set("Enabled" if core.randomization_enabled_in_settings(settings) else "Disabled/Unknown")

    def scan(self):
        def task():
            info = core.get_active_wifi_info()
            self.thread_log(core.get_wlan_settings().rstrip())
            self.thread_log(info.raw.rstrip())
            self.after(0, self.update_status)
        self.run_worker("Scan", task)

    def backup(self):
        def task():
            path = core.create_backup(
                self.thread_log,
                include_wifi_passwords=self.include_passwords.get(),
                include_driver_details=self.include_driver_details.get(),
            )
            self.thread_log(f"Backup created: {path}")
        self.run_worker("Backup", task)

    def fix_randomization(self):
        def task():
            result = core.force_randomization(
                self.thread_log,
                backup_first=True,
                include_passwords_in_backup=self.include_passwords.get(),
            )
            self.thread_log(str(result))
            self.after(0, self.update_status)
        self.run_worker("Enable / Fix Randomization", task)

    def switch_mac(self):
        if not messagebox.askyesno(APP_TITLE, "Switch MAC now? Wi-Fi will disconnect/reconnect for a few seconds."):
            return
        def task():
            result = core.switch_mac_now(self.thread_log)
            self.thread_log(str(result))
            self.after(0, self.update_status)
        self.run_worker("Switch MAC Now", task)

    def disable_randomization(self):
        if not messagebox.askyesno(APP_TITLE, "Disable randomization and reconnect using the adapter's normal MAC?"):
            return
        def task():
            result = core.disable_randomization(self.thread_log)
            self.thread_log(str(result))
            self.after(0, self.update_status)
        self.run_worker("Disable Randomization / Restore Real MAC", task)

    def verify(self):
        def task():
            self.thread_log(core.get_wlan_settings().rstrip())
            self.thread_log(core.get_active_wifi_info().raw.rstrip())
            self.thread_log(core.get_getmac().rstrip())
            self.after(0, self.update_status)
        self.run_worker("Verify", task)

    def save_report(self):
        def task():
            log_text = self.log_box.get("1.0", tk.END)
            path = core.create_report(
                log_text,
                redact=self.redact_report.get(),
                redact_ssids=self.redact_ssids.get(),
            )
            self.thread_log(f"Report saved: {path}")
        self.run_worker("Save Report", task)

    def relaunch_admin(self):
        try:
            core.relaunch_as_admin()
            self.destroy()
        except Exception as exc:
            messagebox.showerror("Relaunch failed", str(exc))


if __name__ == "__main__":
    app = RandMACFixerApp()
    app.mainloop()
