@echo off
cd /d "%~dp0"
py -3 -m py_compile main.py randmac_core.py
if errorlevel 1 goto :err
py -3 tests\test_core_static.py
if errorlevel 1 goto :err
echo.
echo Self-check passed.
pause
exit /b 0

:err
echo.
echo Self-check failed.
pause
exit /b 1
